function formatPixQRCode({ key, name, city, amount, txid }) {
  const format = (id, value) => {
    const size = String(value.length).padStart(2, '0');
    return `${id}${size}${value}`;
  };

  const merchantAccount = format("00", "BR.GOV.BCB.PIX") +
                          format("01", key);

  const additionalData = format("05", txid);

  const payload = format("00", "01") +
    format("26", merchantAccount) +
    format("52", "0000") +
    format("53", "986") +
    format("54", amount.toFixed(2)) +
    format("58", "BR") +
    format("59", name) +
    format("60", city) +
    format("62", additionalData);

  const fullPayload = payload + "6304";
  const crc = crc16(fullPayload);
  return fullPayload + crc;
}

function crc16(str) {
  let crc = 0xFFFF;
  for (let i = 0; i < str.length; i++) {
    crc ^= str.charCodeAt(i) << 8;
    for (let j = 0; j < 8; j++) {
      if ((crc & 0x8000) !== 0) {
        crc = (crc << 1) ^ 0x1021;
      } else {
        crc <<= 1;
      }
      crc &= 0xFFFF;
    }
  }
  return crc.toString(16).toUpperCase().padStart(4, '0');
}
